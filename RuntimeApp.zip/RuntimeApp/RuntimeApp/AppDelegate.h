//
//  AppDelegate.h
//  RuntimeApp
//
//  Created by hour on 2018/7/3.
//  Copyright © 2018年 hour. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

