//
//  RunHello.h
//  TimeApp
//
//  Created by hour on 2018/7/3.
//  Copyright © 2018年 hour. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RunHello : NSObject

//@property (nonatomic, strong) NSString *firstName;
//@property (nonatomic, strong) NSString *lastName;
//@property (nonatomic, strong) NSString *lala;

@property (nonatomic, assign) int age;

- (void)hello;

@end
