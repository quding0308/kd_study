//
//  RunHello.m
//  TimeApp
//
//  Created by hour on 2018/7/3.
//  Copyright © 2018年 hour. All rights reserved.
//

#import "RunHello.h"

@implementation RunHello

+ (void)load {
    NSLog(@"");
    
    
}

+ (void)initialize {
    NSLog(@"");
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSLog(@"");
    }
    return self;
}

- (void)hello {
    
}

@end
