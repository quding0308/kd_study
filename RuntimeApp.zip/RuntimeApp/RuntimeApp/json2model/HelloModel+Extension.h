//
//  HelloModel+Extension.h
//  RuntimeApp
//
//  Created by hour on 2018/7/6.
//  Copyright © 2018年 hour. All rights reserved.
//

#import "HelloModel.h"

@interface HelloModel (Extension)

@property (nonatomic, copy) NSString *extensionStr;

@end
