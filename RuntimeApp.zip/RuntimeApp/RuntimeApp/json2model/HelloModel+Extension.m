//
//  HelloModel+Extension.m
//  RuntimeApp
//
//  Created by hour on 2018/7/6.
//  Copyright © 2018年 hour. All rights reserved.
//

#import "HelloModel+Extension.h"

@implementation HelloModel (Extension)

@end
