//
//  HelloModel.m
//  RuntimeApp
//
//  Created by hour on 2018/7/6.
//  Copyright © 2018年 hour. All rights reserved.
//

#import "HelloModel.h"

#import "HelloModel+Extension.h"

static NSString *_ooo;

@interface HelloModel () {
    NSString *_peter;
    
    NSString *_pp;
}

@end

@implementation HelloModel

@synthesize waka = _peter;


@end
