//
//  TestTaggedPointer.h
//  RuntimeApp
//
//  Created by hour on 2018/9/8.
//  Copyright © 2018 hour. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestTaggedPointer : NSObject

+ (void)test;

@end

NS_ASSUME_NONNULL_END
