//
//  main.m
//  UIWebViewDemo
//
//  Created by hour on 2018/4/6.
//  Copyright © 2018年 hour. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Hello: NSObject {
    
}

+ (void)test;


@end

