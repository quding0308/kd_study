//
//  SuperClass.h
//  TimeApp
//
//  Created by hour on 2017/11/13.
//  Copyright © 2017年 hour. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SuperClass : NSObject

@end
