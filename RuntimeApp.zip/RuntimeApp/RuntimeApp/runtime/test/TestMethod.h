//
//  TestMethod.h
//  RuntimeApp
//
//  Created by hour on 2018/7/4.
//  Copyright © 2018年 hour. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestMethod : NSObject


+ (void)test;

- (void)hello;
- (void)hello1:(NSString *)name;

@end
