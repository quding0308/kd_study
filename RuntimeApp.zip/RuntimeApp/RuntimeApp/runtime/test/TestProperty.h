//
//  TestProperty.h
//  RuntimeApp
//
//  Created by hour on 2018/8/20.
//  Copyright © 2018 hour. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestProperty : NSObject

+ (void)test;

@end
