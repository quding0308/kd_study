//
//  TestSelector.h
//  RuntimeApp
//
//  Created by hour on 2018/7/4.
//  Copyright © 2018年 hour. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestSelector : NSObject

+ (void)test;

@end
