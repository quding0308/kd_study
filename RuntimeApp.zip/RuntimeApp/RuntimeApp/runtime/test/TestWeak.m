//
//  TestWeak.m
//  RuntimeApp
//
//  Created by hour on 2018/9/10.
//  Copyright © 2018 hour. All rights reserved.
//

#import "TestWeak.h"

#import <objc/runtime.h>


@implementation TestWeak

+ (void)test {
//    objc_loadWeak(<#id  _Nullable __autoreleasing * _Nonnull location#>)
    @autoreleasepool {
        
    }
    
}

@end
