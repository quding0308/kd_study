
```
启动调试：
DEBUG=expressapp:* npm start



```