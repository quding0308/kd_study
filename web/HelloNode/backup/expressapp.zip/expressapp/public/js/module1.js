
export function hello() {
    //
    console.log("hello function");
}

export class Kitty {
    hello1() {
        console.log("Hello Kitty11221");
        // debugger;
        console.log("After debugger");
    }
}